export const destinations = [
 {id:"kyoto",category:"culture",jp:"京都",search:"Kyoto 京都 きょうと tea temples",map:"Kyoto Japan",guide:"https://www.japan.travel/en/destinations/kansai/kyoto/",photo:"https://unsplash.com/photos/10000-gates-AiC8MRukmBg",credit:"Jeremy Goldberg"},
 {id:"fuji",category:"nature",jp:"富士山",search:"Fuji 富士山 富士五湖 ふじさん Yamanashi",map:"Lake Kawaguchiko Japan",guide:"https://www.japan.travel/en/destinations/tokai/yamanashi/fuji-five-lakes/",photo:"https://unsplash.com/photos/snow-capped-mount-fuji-under-a-clear-blue-sky-pkyiua_VSh4",credit:"Josip Ivanković"},
 {id:"tokyo",category:"city",jp:"東京",search:"Tokyo 東京 とうきょう Asakusa Shibuya food",map:"Tokyo Japan",guide:"https://www.gotokyo.org/en/",photo:"https://unsplash.com/photos/a-person-walking-down-a-street-at-night-lXR86Iidf7g",credit:"mos design"},
 {id:"kanazawa",category:"culture",jp:"金沢",search:"Kanazawa 金沢 かなざわ garden craft Ishikawa",map:"Kanazawa Japan",guide:"https://www.ishikawatravel.jp/en/destinations/kanazawa/",photo:"https://unsplash.com/photos/japanese-teahouse-sits-on-tranquil-water-HKEfWdXatmg",credit:"Gang Hao"},
 {id:"naoshima",category:"art",jp:"直島",search:"Naoshima 直島 なおしま art Setouchi Kagawa",map:"Naoshima Kagawa Japan",guide:"https://naoshima.net/en/art/",photo:"https://unsplash.com/photos/a-large-body-of-water-surrounded-by-rocks-D5nP4ZMslWo",credit:"Hotaria N"},
 {id:"okinawa",category:"nature",jp:"沖縄",search:"Okinawa 沖縄 おきなわ beach Ryukyu",map:"Okinawa Japan",guide:"https://visitokinawajapan.com/discover/",photo:"https://unsplash.com/photos/a-sandy-beach-under-a-blue-sky-with-clouds-Tkzy4US_AtE",credit:"Sei"}
] as const;
export type Destination = typeof destinations[number];
export const phrases = [
 {key:"phraseHello",ja:"こんにちは",roman:"Konnichiwa"},
 {key:"phraseThanks",ja:"ありがとうございます",roman:"Arigatō gozaimasu"},
 {key:"phraseExcuse",ja:"すみません",roman:"Sumimasen"},
 {key:"phrasePhoto",ja:"写真を撮ってもいいですか？",roman:"Shashin o totte mo ii desu ka?"},
 {key:"phraseWhere",ja:"駅はどこですか？",roman:"Eki wa doko desu ka?"},
 {key:"phraseDiet",ja:"これに肉は入っていますか？",roman:"Kore ni niku wa haitte imasu ka?"}
] as const;


