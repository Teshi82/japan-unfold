import en from "./locales/en.json";
import ja from "./locales/ja.json";
import zhHans from "./locales/zh-Hans.json";
import zhHant from "./locales/zh-Hant.json";
import ko from "./locales/ko.json";
import es from "./locales/es.json";
import fr from "./locales/fr.json";
import ar from "./locales/ar.json";
import it from "./locales/it.json";
import th from "./locales/th.json";
import vi from "./locales/vi.json";
import id from "./locales/id.json";
export const dictionaries = {en, ja, "zh-Hans":zhHans, "zh-Hant":zhHant, ko, es, fr, ar, it, th, vi, id};
export type Locale = keyof typeof dictionaries;
export type TextKey = keyof typeof en;
export const languages: {code:Locale; name:string}[] = [
 {code:"en",name:"English"},{code:"ja",name:"日本語"},{code:"zh-Hans",name:"简体中文"},{code:"zh-Hant",name:"繁體中文"},
 {code:"ko",name:"한국어"},{code:"es",name:"Español"},{code:"fr",name:"Français"},{code:"ar",name:"العربية"},
 {code:"it",name:"Italiano"},{code:"th",name:"ไทย"},{code:"vi",name:"Tiếng Việt"},{code:"id",name:"Bahasa Indonesia"}
];
export function isLocale(value: unknown): value is Locale {
 return typeof value === "string" && Object.prototype.hasOwnProperty.call(dictionaries, value);
}
export function browserLocale(raw:string):Locale {
 const l=raw.toLowerCase();
 if(l.startsWith("zh")) return /hant|tw|hk|mo/.test(l) ? "zh-Hant" : "zh-Hans";
 const base=l.split("-")[0]; return isLocale(base) ? base : "en";
}

