"use client";
import {useEffect,useMemo,useRef,useState} from "react";
import {ArrowUpRight,ArrowRight,Bookmark,Globe2,Search,X,MapPin,Mountain,Leaf,Building2,Palette,Flower2,Check,Download,Camera,Volume1,Heart,MessageCircle,Compass} from "lucide-react";
import {dictionaries,languages,isLocale,browserLocale,type Locale,type TextKey} from "./i18n";
import {destinations,phrases,type Destination} from "./destinations";

const categories = ["all","culture","nature","city","art"] as const;
type Category = typeof categories[number];
type Panel = null | "collection" | "phrases" | "credits" | Destination["id"];
const categoryIcons = {all:Compass,culture:Flower2,nature:Mountain,city:Building2,art:Palette};
const normalize = (v:string) => v.normalize("NFKD").replace(/[\u0300-\u036f]/g,"").toLowerCase();

export default function Home() {
 const [locale,setLocale] = useState<Locale>("en");
 const [query,setQuery]=useState("");
 const [category,setCategory]=useState<Category>("all");
 const [saved,setSaved]=useState<string[]>([]);
 const [panel,setPanel]=useState<Panel>(null);
 const [toast,setToast]=useState("");
 const dialog = useRef<HTMLDialogElement>(null);
 const t=(key:TextKey) => dictionaries[locale][key];
 const placeText=(d:Destination,suffix:"Name"|"Region"|"Tagline"|"Description"|"Tip") => t((d.id+suffix) as TextKey);
 useEffect(()=>{
  let chosen:Locale=browserLocale(navigator.language);
  try {
   const urlLang=new URL(window.location.href).searchParams.get("lang");
   const stored=localStorage.getItem("japan-unfold-language");
   if(isLocale(urlLang)) chosen=urlLang;
   else if(isLocale(stored)) chosen=stored;
   const s=JSON.parse(localStorage.getItem("japan-unfold-collection")||"[]");
   if(Array.isArray(s)) setSaved([...new Set(s.filter((v:unknown)=>typeof v==="string"&&destinations.some(d=>d.id===v)))] as string[]);
  } catch {}
  setLocale(chosen);
 },[]);
 useEffect(()=>{
  document.documentElement.lang=locale;
  document.documentElement.dir=locale==="ar"?"rtl":"ltr";
  document.title="JAPAN, UNFOLD — "+dictionaries[locale].introTitle;
 },[locale]);
 useEffect(()=>{
  if(panel&&!dialog.current?.open) dialog.current?.showModal();
  if(!panel&&dialog.current?.open) dialog.current?.close();
  document.body.style.overflow=panel?"hidden":"";
  if(panel){dialog.current?.scrollTo(0,0);document.getElementById("dialog-title")?.focus({preventScroll:true});}
  return ()=>{document.body.style.overflow=""};
 },[panel]);
 useEffect(()=>{if(!toast)return;const timer=setTimeout(()=>setToast(""),2800);return()=>clearTimeout(timer)},[toast]);
 function changeLanguage(value:string){
  if(!isLocale(value))return;
  setLocale(value);
  try {localStorage.setItem("japan-unfold-language",value)}catch{setToast(dictionaries[value].storageError)}
  const url=new URL(window.location.href);url.searchParams.set("lang",value);history.replaceState(null,"",url);
 }
 function toggleSaved(id:string){
  const next=saved.includes(id)?saved.filter(s=>s!==id):[...saved,id];
  setSaved(next);setToast(t(saved.includes(id)?"removedToast":"savedToast"));
  try{localStorage.setItem("japan-unfold-collection",JSON.stringify(next))}catch{setToast(t("storageError"))}
 }
 const results=useMemo(()=>destinations.filter(d=>{
  const haystack=[d.search,...Object.values(dictionaries).map(dict=>[dict[(d.id+"Name") as TextKey],dict[(d.id+"Region") as TextKey]].join(" ")),placeText(d,"Description"),placeText(d,"Tagline"),t(d.category)].join(" ");
  return (category==="all"||d.category===category)&&normalize(haystack).includes(normalize(query.trim()));
 }),[query,category,locale]);
 const selected=destinations.find(d=>d.id===panel);
 const panelTitle=selected?placeText(selected,"Name"):t(panel==="collection"?"collectionTitle":panel==="phrases"?"phraseTitle":"creditsTitle");
 function downloadCollection(){
  const content=[t("downloadTitle"),...destinations.filter(d=>saved.includes(d.id)).map(d=>[placeText(d,"Name"),placeText(d,"Description"),placeText(d,"Tip"),d.guide].join("\n"))].join("\n\n");
  const url=URL.createObjectURL(new Blob(["\ufeff"+content],{type:"text/plain;charset=utf-8"}));
  const anchor=document.createElement("a");anchor.href=url;anchor.download="my-japan-"+locale+".txt";anchor.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
 }
 const goExplore=()=>document.getElementById("discover")?.scrollIntoView({behavior:window.matchMedia("(prefers-reduced-motion: reduce)").matches?"auto":"smooth"});
 return <>
  <a className="skip-link" href="#discover">{t("skip")}</a>
  <header className="site-header">
   <a href="#" className="brand" aria-label="JAPAN, UNFOLD"><span className="brand-symbol"><span/></span><span>JAPAN<span className="brand-comma">,</span><br/><b>UNFOLD</b></span></a>
   <nav aria-label={t("navExplore")}><a href="#discover">{t("navExplore")}</a><a href="#culture">{t("navCulture")}</a><button onClick={()=>setPanel("phrases")}>{t("navPhrases")}</button></nav>
   <div className="header-tools">
    <label className="language-picker"><Globe2 size={17}/><span className="sr-only">{t("language")}</span><select value={locale} onChange={e=>changeLanguage(e.target.value)}>{languages.map(l=><option key={l.code} value={l.code} lang={l.code}>{l.name}</option>)}</select></label>
    <button className="collection-button" onClick={()=>setPanel("collection")} aria-label={t("saved")+" ("+saved.length+")"}><Bookmark size={18}/><span>{t("saved")}</span>{saved.length>0&&<b>{saved.length}</b>}</button>
   </div>
  </header>
  <main>
   <section className="hero">
    <img className="hero-image" src="./fuji.jpg" alt={t("heroLocation")} fetchPriority="high"/>
    <div className="hero-shade"/>
    <div className="hero-content"><p className="eyebrow light"><span/>{t("heroEyebrow")}</p><h1>{t("heroTitle")}</h1><p className="hero-description">{t("heroText")}</p><button className="cream-button" onClick={goExplore}>{t("heroCta")}<ArrowUpRight size={19}/></button></div>
    <div className="hero-side" aria-hidden="true"><span lang="ja">まだ知らない、日本へ。</span><span>35°21′ N &nbsp; 138°44′ E</span></div>
    <div className="hero-bottom"><div><MapPin size={15}/><span>{t("heroLocation")}</span></div><p>{t("heroCaption")}</p><span className="hero-number" aria-hidden="true">01 <i/> 06</span></div>
   </section>
   <div className="search-wrap"><form className="search-bar" onSubmit={e=>{e.preventDefault();setCategory("all");goExplore()}}><Search size={22}/><input aria-label={t("searchLabel")} placeholder={t("searchPlaceholder")} value={query} onChange={e=>setQuery(e.target.value)}/>{query&&<button className="clear-search" type="button" aria-label={t("reset")} onClick={()=>setQuery("")}><X size={17}/></button>}<button className="search-submit" type="submit">{t("search")}<ArrowRight size={18}/></button></form></div>
   <section className="discovery section-shell" id="discover">
    <div className="section-heading"><div><p className="eyebrow">{t("introLabel")}</p><h2>{t("introTitle")}</h2></div><p>{t("introText")}</p></div>
    <div className="filter-line"><div className="filters" aria-label={t("navExplore")}>{categories.map(c=>{const Icon=categoryIcons[c];return <button key={c} className={category===c?"active":""} onClick={()=>setCategory(c)} aria-pressed={category===c}><Icon size={16}/>{t(c)}</button>})}</div><span className="result-count" aria-live="polite">{t("resultCount").replace("{count}",new Intl.NumberFormat(locale).format(results.length))}</span></div>
    <div className="places-grid">{results.map((d,index)=><article className="place-card" key={d.id}>
     <div className="card-visual"><button className="image-button" onClick={()=>setPanel(d.id)} aria-label={placeText(d,"Name")+" — "+t("readStory")}><img src={"./"+d.id+".jpg"} alt={placeText(d,"Name")} loading="lazy"/><span className="japanese-name" lang="ja" aria-hidden="true">{d.jp}</span></button><span className="category-label">{t(d.category)}</span><button className={"save-button "+(saved.includes(d.id)?"is-saved":"")} onClick={()=>toggleSaved(d.id)} aria-pressed={saved.includes(d.id)} aria-label={t(saved.includes(d.id)?"removePlace":"savePlace")+" — "+placeText(d,"Name")}><Bookmark size={18} fill={saved.includes(d.id)?"currentColor":"none"}/></button></div>
     <div className="card-info"><p className="region">{placeText(d,"Region")}</p><div className="card-title-row"><h3><button onClick={()=>setPanel(d.id)}>{placeText(d,"Name")}</button></h3><button className="round-link" onClick={()=>setPanel(d.id)} aria-label={t("readStory")+" — "+placeText(d,"Name")}><ArrowUpRight size={20}/></button></div><p className="tagline">{placeText(d,"Tagline")}</p></div>
    </article>)}</div>
    {!results.length&&<div className="empty-state"><Compass size={36}/><h3>{t("noResults")}</h3><p>{t("noResultsText")}</p><button className="green-button" onClick={()=>{setQuery("");setCategory("all")}}>{t("reset")}</button></div>}
   </section>
   <section className="culture-section" id="culture"><div className="section-shell culture-inner"><div className="culture-intro"><p className="eyebrow">{t("cultureLabel")}</p><h2>{t("cultureTitle")}</h2><p>{t("cultureText")}</p><button className="text-link" onClick={()=>setPanel("phrases")}>{t("phraseCta")}<ArrowUpRight size={18}/></button><div className="enso" aria-hidden="true"><span lang="ja">心</span></div></div><div className="culture-tips">{[{icon:Volume1,n:1},{icon:Camera,n:2},{icon:Leaf,n:3}].map(({icon:Icon,n})=><article key={n}><div className="tip-icon"><Icon size={23}/></div><div><span className="tip-number">0{n}</span><h3>{t(("tip"+n+"Title") as TextKey)}</h3><p>{t(("tip"+n+"Text") as TextKey)}</p></div></article>)}</div></div></section>
   <section className="closing-strip section-shell"><Flower2 size={30}/><p>{t("footerTagline")}</p><span lang="ja" aria-hidden="true">一期一会</span></section>
  </main>
  <footer className="site-footer section-shell"><div><a className="footer-brand" href="#" dir="ltr">JAPAN, UNFOLD</a><p>{t("footerAbout")}</p></div><div><button onClick={()=>setPanel("credits")}>{t("credits")}<ArrowUpRight size={15}/></button><p>{t("privacy")}</p></div></footer>
  <dialog ref={dialog} className={"app-dialog "+(panel==="collection"?"collection-dialog":"")} aria-labelledby="dialog-title" onCancel={()=>setPanel(null)} onClick={e=>{if(e.target===e.currentTarget)setPanel(null)}}>
   <div className="dialog-inner"><button className="dialog-close" onClick={()=>setPanel(null)} aria-label={t("close")}><X size={22}/></button>
   {selected&&<img className="detail-image" src={"./"+selected.id+".jpg"} alt={placeText(selected,"Name")}/>}
   <div className="dialog-content">{selected&&<p className="eyebrow">{placeText(selected,"Region")}</p>}<h2 id="dialog-title" tabIndex={-1}>{panelTitle}</h2>
    {selected&&<><p className="detail-lead">{placeText(selected,"Description")}</p><div className="travel-note"><Leaf size={22}/><div><h3>{t("beforeYouGo")}</h3><p>{placeText(selected,"Tip")}</p></div></div><div className="detail-actions"><button className="green-button" onClick={()=>toggleSaved(selected.id)}>{saved.includes(selected.id)?<Check size={18}/>:<Bookmark size={18}/>} {t(saved.includes(selected.id)?"removePlace":"savePlace")}</button><a className="outline-button" href={selected.guide} target="_blank" rel="noopener noreferrer">{t("official")}<ArrowUpRight size={17}/></a><a className="map-link" href={"https://www.google.com/maps/search/?api=1&query="+encodeURIComponent(selected.map)} target="_blank" rel="noopener noreferrer"><MapPin size={16}/>{t("map")}</a></div><p className="detail-note">{t("detailNote")}</p><p className="photo-credit"><a href={selected.photo} target="_blank" rel="noopener noreferrer">© {selected.credit} / Unsplash <ArrowUpRight size={12}/></a></p></>}
    {panel==="collection"&&<><p className="dialog-intro">{t("collectionText")}</p>{saved.length?<><div className="saved-list">{destinations.filter(d=>saved.includes(d.id)).map(d=><article key={d.id}><button onClick={()=>setPanel(d.id)} className="saved-image"><img src={"./"+d.id+".jpg"} alt={placeText(d,"Name")}/></button><div><p className="region">{placeText(d,"Region")}</p><button className="saved-name" onClick={()=>setPanel(d.id)}>{placeText(d,"Name")}</button><p>{placeText(d,"Tagline")}</p></div><button className="remove-saved" onClick={()=>toggleSaved(d.id)} aria-label={t("removePlace")+" — "+placeText(d,"Name")}><X size={18}/></button></article>)}</div><button className="green-button download-button" onClick={downloadCollection}><Download size={18}/>{t("download")}</button></>:<div className="empty-state"><Bookmark size={35}/><h3>{t("collectionEmpty")}</h3><p>{t("collectionEmptyText")}</p><button className="green-button" onClick={()=>{setPanel(null);goExplore()}}>{t("navExplore")}</button></div>}</>}
    {panel==="phrases"&&<><p className="dialog-intro">{t("phraseIntro")}</p><div className="phrase-list">{phrases.map(p=><article key={p.key}><MessageCircle size={19}/><div><p>{t(p.key)}</p><strong lang="ja" dir="ltr">{p.ja}</strong><span lang="ja-Latn" dir="ltr">{p.roman}</span></div></article>)}</div><p className="detail-note">{t("phraseNote")}</p></>}
    {panel==="credits"&&<><p className="dialog-intro">{t("creditsText")}</p><div className="credit-list">{destinations.map(d=><article key={d.id}><strong>{placeText(d,"Name")}</strong><a href={d.guide} target="_blank" rel="noopener noreferrer">{t("official")} ↗</a><a href={d.photo} target="_blank" rel="noopener noreferrer">{d.credit} / Unsplash ↗</a></article>)}</div><a className="text-link" href="https://unsplash.com/license" target="_blank" rel="noopener noreferrer">{t("license")}<ArrowUpRight size={15}/></a></>}
   </div>{panel&&<div role="status" className={"dialog-toast "+(toast?"show":"")}><Check size={17}/>{toast}</div>}</div>
  </dialog>
  <div role={panel?undefined:"status"} aria-hidden={panel?true:undefined} className={"toast "+(!panel&&toast?"show":"")}><Check size={17}/>{toast}</div>
 </>;
}





